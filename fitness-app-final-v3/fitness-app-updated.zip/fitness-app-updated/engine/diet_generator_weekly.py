import os
import json
from typing import Dict, Any
from dotenv import load_dotenv
from .ai_handler import generate_with_ai

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DOTENV_PATH = os.path.join(BASE_DIR, ".env")
load_dotenv(DOTENV_PATH)


def extract_json_from_text(text):
    """Extract JSON from AI response."""
    text = text.strip()
    
    # Remove markdown
    if "```json" in text:
        text = text.split("```json")[1].split("```")[0]
    elif "```" in text:
        parts = text.split("```")
        if len(parts) >= 3:
            text = parts[1]
    
    # Find JSON object
    start = text.find("{")
    end = text.rfind("}")
    
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]
    
    return text.strip()


def generate_weekly_diet_plan(targets: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generates a personalized WEEKLY (7-day) diet plan.
    """

    cals = targets['calories']
    prot = targets['macros']['protein']
    carb = targets['macros']['carbs']
    fats = targets['macros']['fats']
    meals = profile.get('meals_per_day', 4)

    prompt = f"""You are a nutritionist. Create a 7-day meal plan in JSON format.

REQUIREMENTS:
- Calories: {cals} kcal/day
- Protein: {prot}g | Carbs: {carb}g | Fats: {fats}g  
- Diet: {profile.get('diet_type', 'General')}
- Allergies: {', '.join(profile.get('allergies', [])) or 'None'}
- Meals: {meals} per day

Return ONLY valid JSON (no markdown, no explanations):

{{
  "summary": {{
    "total_calories_per_day": {cals},
    "protein_per_day": {prot},
    "carbs_per_day": {carb},
    "fats_per_day": {fats},
    "note": "Balanced weekly plan"
  }},
  "days": [
    {{
      "day": "Monday",
      "total_calories": {cals},
      "meals": [
        {{
          "meal_name": "Breakfast",
          "food_items": [
            {{
              "item": "Oatmeal with berries",
              "quantity": "1 bowl",
              "calories": 350,
              "protein": 12,
              "carbs": 55,
              "fats": 8,
              "prep_note": "Cook with milk"
            }}
          ]
        }}
      ]
    }}
  ]
}}

Generate ALL 7 days (Monday-Sunday) with {meals} meals each. Vary the meals across days. Each day should total approximately {cals} calories."""

    # Retry up to 3 times
    max_retries = 3
    for attempt in range(max_retries):
        try:
            success, response_text, error = generate_with_ai(prompt, max_tokens=8192, key_type='diet')
            
            if not success:
                if attempt < max_retries - 1:
                    continue
                return {
                    "error": "Could not generate diet plan.",
                    "details": str(error)
                }
            
            # Extract JSON
            raw_text = extract_json_from_text(response_text)
            diet_plan = json.loads(raw_text)
            
            # Validate
            if "days" not in diet_plan:
                raise ValueError("Missing 'days' field")
            
            return diet_plan
            
        except (json.JSONDecodeError, ValueError) as e:
            if attempt < max_retries - 1:
                continue
            # Show more of the response for debugging
            print(f"=" * 70)
            print(f"ERROR Diet Plan - Attempt {attempt + 1}/{max_retries}")
            print(f"Parse Error: {str(e)}")
            print(f"=" * 70)
            print("AI Response (first 800 chars):")
            print(response_text[:800] if response_text else "No response")
            print(f"=" * 70)
            return {
                "error": "Failed to parse diet plan.",
                "details": f"Parse error: {str(e)}. Check terminal for full AI response."
            }
        except Exception as e:
            if attempt < max_retries - 1:
                continue
            return {
                "error": "Unexpected error.",
                "details": str(e)
            }